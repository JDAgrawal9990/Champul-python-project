import pygame
import random


pygame.init()
#dicee = [1, 2, 3, 4, 8]

running = True
screen = pygame.display.set_mode((750, 750), pygame.RESIZABLE)
# create title and icon
pygame.display.set_caption("Champul Game")
icon = pygame.image.load("project.png")
pygame.display.set_icon(icon)

clock= pygame.time.Clock()
# create a background board
floor = pygame.image.load("champulboard.gif")
floor = pygame.transform.scale(floor, (750,750))

# load piece image
piece_yellow = pygame.image.load("yellow.png")
piece_yellow = pygame.transform.scale(piece_yellow, (33.33,50))
x, y = 50, 350
initial_position = 0
final_position = 0
yellow_state = "in"


# piece blue
piece_blue = pygame.image.load("blue.png")
piece_blue = pygame.transform.scale(piece_blue, (33.33,50))
blue_x, blue_y = 350, 650
init_pos = 0
fin_pos = 0
blue_state = "in"

# piece red
piece_red = pygame.image.load("red.png")
piece_red = pygame.transform.scale(piece_red, (33.33,50))
red_x, red_y = 650, 350
init_position = 0
fin_position = 0
red_state ="in"

# piece green
piece_green = pygame.image.load("green.png")
piece_green = pygame.transform.scale(piece_green, (33.33,50))
green_x, green_y = 350, 50
initi_position = 0
fina_position = 0
green_state ="in"

# load dice image
cowry1 = pygame.image.load("cowry1.png")
cowry2 = pygame.image.load("cowry2.png")
cowry3 = pygame.image.load("cowry3.png")
cowry4 = pygame.image.load("cowry4.png")
cowry8 = pygame.image.load("cowry8.png")
dice_list = [cowry1, cowry2, cowry3, cowry4]

# x & y coordination of moves
piece_listy = [(36, 468), (37.5, 487.5), (37.5, 637.5), (187.5, 637.5), (337.5,637.5), (487.5, 637.5), (637.5, 637.5), 
               (637.5, 487.5), (637.5, 337.5), (637.5, 187.5), (637.5, 37.5), (487.5, 37.5), (337.5, 37.5), (187.5, 37.5), 
               (37.5,37.5), (37.5, 187.5), (187.5, 187.5), (337.5, 187.5), (487.5, 187.5), (487.5, 337.5), (487.5, 487.5),
               (337.5, 487.5), (187.5, 487.5), (187.5, 337.5), (337.5, 337.5)]
piece_listb = [(468, 900), (487.5, 637.5), (637.5, 637.5), (637.5, 487.5), (637.5, 337.5), (637.5, 187.5), (637.5, 37.5),
               (487.5, 37.5), (337.5, 37.5), (187.5, 37.5), (37.5, 37.5), (37.5, 187.5), (37.5, 337.5), (37.5, 487.5), (37.5, 637.5),
               (187.5, 637.5), (187.5, 487.5), (187.5, 337.5), (187.5, 187.5), (337.5, 187.5), (487.5, 187.5), (487.5, 337.5), (487.5, 487.5), (337.5, 487.5),
               (337.5,337.5)]
piece_listr = [(900, 468), (637.5, 187.5), (637.5,37.5), (487.5, 37.5), (337.5, 37.5), (187.5, 37.5), (37.5, 37.5),
               (37.5, 187.5), (37.5, 337.5), (37.5, 487.5), (37.5, 637.5), (187.5, 637.5), (337.5, 637.5), (487.5, 637.5),
               (637.5, 637.5), (637.5, 487.5), (487.5, 487.5), (337.5, 487.5), (187.5, 487.5), (187.5, 337.5), (187.5, 187.5),
               (337.5, 187.5), (487.5, 187.5), (487.5, 337.5), (337.5, 337.5)]
piece_listg = [(468, 36), (187.5, 37.5), (37.5, 37.5), (37.5, 187.5), (37.5, 337.5), (37.5, 487.5), (37.5, 637.5), (187.5, 637.5), 
               (337.5, 637.5), (487.5, 637.5), (637.5, 637.5), (637.5, 487.5), (637.5, 337.5), (637.5, 187.5), (637.5, 37.5), (487.5, 37.5),
               (487.5, 187.5), (487.5, 337.5), (487.5, 487.5), (337.5, 487.5), (187.5, 487.5), (487.5, 337.5), (187.5, 187.5), (337.5, 187.5),
               (337.5, 337.5)]               
turn = "Blue Turn"
font = pygame.font.Font("freesansbold.ttf", 24)
over_font = pygame.font.Font("freesansbold.ttf", 64)
blastimg1 = pygame.image.load("bluesafe.png")
blastimg1 = pygame.transform.scale(blastimg1, (155,155))
blastimg2 = pygame.image.load("redsafe.png")
blastimg2 = pygame.transform.scale(blastimg2, (155,155))
blastimg3 = pygame.image.load("greensafe.png")
blastimg3 = pygame.transform.scale(blastimg3, (155,155))
blastimg4 = pygame.image.load("yellowsafe.png")
blastimg4 = pygame.transform.scale(blastimg4, (155,155))
blastimg5 = pygame.image.load("center.png")
blastimg5 = pygame.transform.scale(blastimg5, (155,155))
last_turn = " "


def background(x, y):
    screen.blit(floor, (x, y))


def dice(a):
    screen.blit(dice_list[a - 1], (300, 337.5))


def yellow(x, y):
    screen.blit(piece_yellow, (x, y))


def blue(x, y):
    screen.blit(piece_blue, (x, y))


def red(x, y):
    screen.blit(piece_red, (x, y))

def green(x, y):
    screen.blit(piece_green, (x, y))

def show_turn(text):
    turn_text = font.render(text, True, (255, 255, 255))
    screen.blit(turn_text, (15, 15))


def move_blue(piece_img, final_pos, ypos, gpos, rpos, turn):
    global init_pos
    screen.blit(piece_img, piece_listb[final_pos])
    init_pos = final_pos
    if last_turn == "Blue Turn" and turn == "Blue Turn":
        iscollision(final_pos, ypos, gpos, rpos)
    if turn == "Red Turn" and last_turn != "Red Turn":
        iscollision(final_pos, ypos, gpos, rpos)
    game_over(final_pos, ypos, gpos, rpos)


def move_yellow(piece_img, final_pos, bpos, rpos, gpos, turn):
    # print(turn)
    global initial_position
    screen.blit(piece_img, piece_listy[final_pos])
    initial_position = final_pos
    if last_turn == "Yellow Turn" and turn == "Yellow Turn":
        iscollision(final_pos, bpos, rpos, gpos)
    if turn == "Blue Turn" and last_turn != "Blue Turn":
        iscollision(final_pos, bpos, rpos, gpos)
    game_over(bpos, final_pos, gpos, rpos)


def move_red(piece_img, final_pos, ypos, bpos, gpos, turn): 
    global init_position
    screen.blit(piece_img, piece_listr[final_pos])
    init_position = final_pos
    if last_turn == "Red Turn" and turn == "Red Turn":
        iscollision(final_pos, ypos, bpos, gpos)
    if turn == "Green turn" and turn != "Green Turn":
        iscollision(final_pos, ypos, bpos, gpos)     
    game_over(bpos, ypos, gpos, final_pos)

def move_green(piece_img, final_pos, ypos, bpos, rpos, turn):
    global initi_position
    screen.blit(piece_img, piece_listg[final_pos])
    initi_position = final_pos
    if last_turn == "Green Turn" and turn == "Green Turn":
        iscollision(final_pos, ypos, bpos, rpos)
    if turn == "Yellow Turn" and last_turn != "Yellow Turn":
        iscollision(final_pos, ypos, bpos, rpos)
    game_over(bpos, ypos, final_pos, rpos)

def iscollision(first_pos, op1_pos, op2_pos, op3_pos):
    global initial_position, final_position, init_pos, fin_pos, yellow_state, blue_state, init_position, fin_position, red_state, initi_position, fina_position, green_state, turn
    if turn == "Green Turn":
        # distance = math.sqrt(math.pow(enemyx - bulletx, 2) + math.pow(enemyy - bullety, 2))
        if piece_listr[first_pos][0] == piece_listy[op1_pos][0] and piece_listr[first_pos][1] == piece_listy[op1_pos][
            1]:
            print("collision R to Y")
            print(piece_listr[first_pos][0], piece_listy[op1_pos][0], ":", piece_listr[first_pos][1],
                  piece_listy[op1_pos][
                      1])
            initial_position = 0
            final_position = 0
            yellow_state = "in"
            turn = "Red Turn"
        if piece_listr[first_pos][0] == piece_listb[op2_pos][0] and piece_listr[first_pos][1] == piece_listb[op2_pos][
            1]:
            print("collision R to B")
            print(piece_listr[first_pos][0], piece_listb[op2_pos][0], ":", piece_listr[first_pos][1],
                  piece_listb[op2_pos][
                      1])
            init_pos = 0
            fin_pos = 0
            blue_state = "in"
            turn = "Red Turn"
        if piece_listr[first_pos][0] == piece_listg[op3_pos][0] and piece_listr[first_pos][1] == piece_listg[op3_pos][
            1]:
            print("collision R to G")
            print(piece_listr[first_pos][0], piece_listg[op3_pos][0], ":", piece_listr[first_pos][1],
                  piece_listg[op3_pos][
                      1])
            initi_position = 0
            fina_position = 0
            green_state = "in"
            turn = "Red Turn"    
    elif turn == "Blue Turn":
        if piece_listy[first_pos][0] == piece_listb[op1_pos][0] and piece_listy[first_pos][1] == piece_listb[op1_pos][
            1]:
            print("collision Y to B")
            print(piece_listy[first_pos][0], piece_listb[op1_pos][0], ":", piece_listy[first_pos][1],
                  piece_listb[op1_pos][1])
            init_pos = 0
            fin_pos = 0
            blue_state = "in"
            turn = "Yellow Turn"
        if piece_listy[first_pos][0] == piece_listr[op2_pos][0] and piece_listy[first_pos][1] == piece_listr[op2_pos][
            1]:
            print("collision Y to R")
            print(piece_listy[first_pos][0], piece_listr[op2_pos][0], ":", piece_listy[first_pos][1],
                  piece_listr[op2_pos][1])
            init_position = 0
            fin_position = 0
            red_state = "in"
            turn = "Yellow Turn"
        if piece_listy[first_pos][0] == piece_listg[op3_pos][0] and piece_listy[first_pos][1] == piece_listg[op3_pos][
            1]:
            print("collision Y to G")
            print(piece_listy[first_pos][0], piece_listg[op3_pos][0], ":", piece_listy[first_pos][1],
                  piece_listg[op3_pos][1])
            initi_position = 0
            fina_position = 0
            green_state = "in"
            turn = "Yellow Turn"    
    elif turn == "Red Turn":
        if (piece_listb[first_pos][0] == piece_listr[op2_pos][0] and piece_listb[first_pos][1] == piece_listr[op2_pos][
            1]):
            print("collision B to R")
            print(piece_listb[first_pos][0], piece_listr[op2_pos][0], ":", piece_listb[first_pos][1],
                  piece_listr[op2_pos][1])
            init_position = 0
            fin_position = 0
            red_state = "in"
            turn = "Blue Turn"
        if (piece_listb[first_pos][0] == piece_listy[op1_pos][0] and piece_listb[first_pos][1] == piece_listy[op1_pos][
            1]):
            print("collision B to Y")
            print(piece_listb[first_pos][0], piece_listy[op1_pos][0], ":", piece_listb[first_pos][1],
                  piece_listy[op1_pos][1])
            initial_position = 0
            final_position = 0
            yellow_state = "in"
            turn = "Blue Turn"
        if (piece_listb[first_pos][0] == piece_listg[op3_pos][0] and piece_listb[first_pos][1] == piece_listg[op3_pos][
            1]):
            print("collision B to G")
            print(piece_listb[first_pos][0], piece_listg[op3_pos][0], ":", piece_listb[first_pos][1],
                  piece_listg[op3_pos][1])
            initi_position = 0
            fina_position = 0
            green_state = "in"
            turn = "Blue Turn"    
    elif turn == "Yellow Turn":
        if (piece_listg[first_pos][0] == piece_listr[op2_pos][0] and piece_listg[first_pos][1] == piece_listr[op2_pos][
            1]):
            print("collision G to R")
            print(piece_listg[first_pos][0], piece_listr[op2_pos][0], ":", piece_listg[first_pos][1],
                  piece_listr[op2_pos][1])
            init_position = 0
            fin_position = 0
            red_state = "in"
            turn = "Green Turn"
        if (piece_listg[first_pos][0] == piece_listy[op1_pos][0] and piece_listg[first_pos][1] == piece_listy[op1_pos][
            1]):
            print("collision G to Y")
            print(piece_listg[first_pos][0], piece_listy[op1_pos][0], ":", piece_listg[first_pos][1],
                  piece_listy[op1_pos][1])
            initial_position = 0
            final_position = 0
            yellow_state = "in"
            turn = "Green Turn"
        if piece_listr[first_pos][0] == piece_listb[op3_pos][0] and piece_listr[first_pos][1] == piece_listb[op3_pos][
            1]:
            print("collision G to B")
            print(piece_listg[first_pos][0], piece_listb[op3_pos][0], ":", piece_listg[first_pos][1],
                  piece_listb[op3_pos][
                      1])
            init_pos = 0
            fin_pos = 0
            blue_state = "in"
            turn = "Green Turn"    


def game_over(blue_pos, yellow_pos, red_pos, green_pos):
    global turn
    if (piece_listb[blue_pos][0], piece_listb[blue_pos][1]) == (337.5, 337.5) or (
            piece_listy[yellow_pos][0], piece_listy[yellow_pos][1]) == (337.5, 337.5) or (
            piece_listr[red_pos][0], piece_listr[red_pos][1]) == (337.5, 337.5) or (
            piece_listg[green_pos][0], piece_listg[green_pos][1]) == (337.5, 337.5):
        game_over_text = over_font.render("GAME OVER", True, (255, 0, 0))
        screen.blit(game_over_text, (175, 350 ))
        turn = "No Turn"


a = 0
d = 0
# game loop
while running:

    # fill the screen with black colour
    screen.fill((0, 0, 0))
    clock.tick(60)
    # check for the event happen in pygame
    for event in pygame.event.get():

        # check if exit key is pressed
        if event.type == pygame.QUIT:
            running = False

        # check if key is pressed
        if event.type == pygame.KEYDOWN:
            # space key to change the dice
            if event.key == pygame.K_SPACE:
                
                a = random.randint(1, 4)
                
                
                d = a
                last_turn = turn
                
                if turn == "Blue Turn":
                    # Piece will out first only when 4 appers
                    if a == 4 and blue_state == "in":
                        blue_state = "out"
                        fin_pos = 1
                    # if piece are already out
                    elif blue_state == "out":
                        last_posb = fin_pos
                        fin_pos = init_pos + a
                        if fin_pos > 25:
                            fin_pos = last_posb
                    # if initially 4 is not appears then make a=0
                    else:
                        a = 0
                    turn = "Red Turn"
                    if a == 4:
                        turn = "Blue Turn"
                
                elif turn == "Red Turn":
                    # Piece will out first only when 4 appears
                    if a == 4 and red_state == "in":
                        red_state = "out"
                        fin_position = 1
                    # if piece are already out
                    elif red_state == "out":
                        last_posr = fin_position
                        fin_position = init_position + a
                        if fin_position > 25:
                            fin_position = last_posr
                    # if initially 4 is not appears then make a=0
                    else:
                        a = 0
                    turn = "Green Turn"
                    if a == 4:
                        turn = "Red Turn"
                  
                elif turn == "Green Turn":
                    # Piece will out first only when 4 appears
                    if a == 4 and red_state == "in":
                        green_state = "out"
                        fina_position = 1
                    # if piece are already out
                    elif green_state == "out":
                        last_posg = fina_position
                        fina_position = initi_position + a
                        if fina_position > 25:
                            fina_position = last_posg
                    # if initially 4 is not appears then make a=0
                    else:
                        a = 0
                    turn = "Yellow Turn"
                    if a == 4:
                        turn = "Green Turn"
                
                elif turn == "Yellow Turn":
                    # Piece will out first only when 4 appears
                    if a == 4 and yellow_state == "in":
                        yellow_state = "out"
                        final_position = 1
                    # if piece are already out
                    elif yellow_state == "out":
                        last_posy = final_position
                        final_position = initial_position + a
                        if final_position > 25:
                            final_position = last_posy
                    # if initially 4 is not appears then make a=0
                    else:
                        a = 0
                    turn = "Blue Turn"
                    if a == 4:
                        turn = "Yellow Turn"
        
    background(0, 0)
    screen.blit(blastimg1, (295, 595))
    screen.blit(blastimg2, (595, 295))
    screen.blit(blastimg3, (295, 0))
    screen.blit(blastimg4, (0, 295))
    screen.blit(blastimg5, (295, 295))


    show_turn(turn)
    # to show dice
    if d != 0:
        dice(d)
    # to show piece
    if a == 0:
        if yellow_state == "in":
            yellow(x, y)
        if blue_state == "in":
            blue(blue_x, blue_y)
        if red_state == "in":
            red(red_x, red_y)
        if green_state == "in":
            green(green_x, green_y)    
 
    # to move piece
    move_blue(piece_blue, fin_pos, final_position, fina_position, fin_position, turn)
    move_yellow(piece_yellow, final_position, fin_pos, fin_position, fina_position,  turn)
    move_red(piece_red, fin_position, final_position, fin_pos, fina_position, turn)
    move_green(piece_green, fina_position,  final_position, fin_pos, fin_position, turn)

    # update the display
    pygame.display.update()
